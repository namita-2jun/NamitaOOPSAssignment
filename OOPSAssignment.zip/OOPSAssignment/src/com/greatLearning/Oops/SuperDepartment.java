package com.greatLearning.Oops;
/*
 * SuperDeaprtment is a super class
 */

public class SuperDepartment {
	
	public String departmentName() {
		return "Super Department";
	}
	public String getTodaysWork() {
		return "No Work as of now";
	}
	//method to get work Deadline
	
	public String getWorkDeadline() {
		return "Nil";
	}
	/**
	 * @return
	 */
	public String isTodayHoliday() {
		return "Today is not a Holiday";
	}
}
