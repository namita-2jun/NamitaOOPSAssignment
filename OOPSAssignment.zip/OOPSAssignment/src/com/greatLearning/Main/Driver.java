package com.greatLearning.Main;

import com.greatLearning.Oops.AdminDepartment;
import com.greatLearning.Oops.HRDepartment;
import com.greatLearning.Oops.SuperDepartment;
import com.greatLearning.Oops.TechDepartment;

public class Driver {

	/**
	 * This class contains the main method to call the subclasses of superclass SuperDepartment
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		/*
		 * Admin Department Details
		 * */
		SuperDepartment obj = new AdminDepartment();
		String adminDepartment = obj.departmentName();
		System.out.println("Welcome to "+adminDepartment);
		String todaysWork = obj.getTodaysWork();
		System.out.println(todaysWork);
		String workDeadline = obj.getWorkDeadline();
		System.out.println(workDeadline);
		String holidayDetails = obj.isTodayHoliday();
		System.out.println(holidayDetails);
		System.out.println();
		System.out.println();

		/*
		 * HR Department Details
		 * 
		 */
		HRDepartment hrObj = new HRDepartment();;
		String hrDepartment = hrObj.departmentName();
		System.out.println("Welcome to "+hrDepartment);
		String activity = hrObj.doActivity();
		System.out.println(activity);
		String workDetails = hrObj.getTodaysWork();
		System.out.println(workDetails);
		String hrWorkDeadline = hrObj.getWorkDeadline();
		System.out.println(hrWorkDeadline);
		System.out.println(holidayDetails);
		System.out.println();
		System.out.println();
		
		/*
		 * Tech Department Details
		 */
		
		TechDepartment techDepartment = new TechDepartment();
		String techDepartmentName = techDepartment.departmentName();
		System.out.println("Welcome to "+techDepartmentName);
		String workStatus = techDepartment.getTodaysWork();
		System.out.println(workStatus);
		String workTimeline = techDepartment.getWorkDeadline();
		System.out.println(workTimeline);
		String stackInformation = techDepartment.getTechStackInformation();
		System.out.println(stackInformation);
		System.out.println(holidayDetails);
		
		
		

	}

}
